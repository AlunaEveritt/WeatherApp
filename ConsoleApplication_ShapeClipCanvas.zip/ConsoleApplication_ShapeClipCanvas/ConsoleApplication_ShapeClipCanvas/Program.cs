﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quobject.SocketIoClientDotNet.Client;

namespace ConsoleApplication_ShapeClipCanvas
{
    class Program
    {
        /// <summary> Socket reference to connect to server. </summary>
        private Socket socket = null;

        /// <summary> IP address of main server. </summary>
        private String SERVER_IP = "localhost";

        /// <summary> Port which server is listening to. </summary>
        private String SERVER_PORT = "3000";

        public Program()
        {
            
        }

        public void ReadSerial()
        {
            StartSocketConnection();
            SerialPort port = new SerialPort("COM2", 9600);
            port.Open();
            Console.WriteLine("Opened port, waiting for data");
            while (true)
            {
                String s = port.ReadLine();
                Console.WriteLine(s);
                socket.Emit("ARDUINO_SERIAL", s);
            }
        }

        public void StartSocketConnection()
        {
            Console.WriteLine("Attempting to connect to socket");
            // Establish a connection to the server and port
            socket = IO.Socket("http://" + SERVER_IP + ":" + SERVER_PORT);
            
            socket.On(Socket.EVENT_CONNECT, () =>
            {
                Console.WriteLine("Connection established to server!");
            });
            //Console.ReadLine();
      
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            p.ReadSerial();
        }
    }
}
